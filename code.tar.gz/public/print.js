(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const loading = $('#printLoading');
  const error = $('#printError');
  const card = $('#printCard');
  const actions = $('#printActions');
  const escapeHtml = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const printParams = new URLSearchParams(window.location.search);
  const codeId = printParams.get('id');
  const isManager = printParams.get('role') === 'manager';
  async function draw(canvas, code, publicBaseUrl) {
    const data=`${publicBaseUrl || window.location.origin}/r/${encodeURIComponent(code.publicCode)}`;
    if(window.QRIAQRArtwork?.renderCanvas){await window.QRIAQRArtwork.renderCanvas(canvas,data,code.style||{},1024);return;}
    const qr = qrcode(0, code.style?.correction || 'M');
    qr.addData(`${publicBaseUrl || window.location.origin}/r/${encodeURIComponent(code.publicCode)}`); qr.make();
    const count = qr.getModuleCount(), margin = 4, total = count + margin * 2, size = 1024;
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d', { alpha: false }); ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = code.style?.background || '#FFFFFF'; ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = code.style?.foreground || '#111111';
    const dotStyle = ['square', 'rounded', 'dots'].includes(code.style?.dotStyle) ? code.style.dotStyle : 'square';
    for (let row = 0; row < count; row += 1) for (let col = 0; col < count; col += 1) if (qr.isDark(row, col)) {
      const x0 = Math.round(((col + margin) / total) * size), x1 = Math.round(((col + margin + 1) / total) * size);
      const y0 = Math.round(((row + margin) / total) * size), y1 = Math.round(((row + margin + 1) / total) * size);
      const width = x1 - x0, height = y1 - y0;
      const finderZone = (row < 8 && col < 8) || (row < 8 && col >= count - 8) || (row >= count - 8 && col < 8);
      if (!finderZone && dotStyle === 'dots') { ctx.beginPath(); ctx.arc((x0 + x1) / 2, (y0 + y1) / 2, Math.max(1, Math.min(width, height) * 0.34), 0, Math.PI * 2); ctx.fill(); }
      else if (!finderZone && dotStyle === 'rounded' && typeof ctx.roundRect === 'function') { ctx.beginPath(); ctx.roundRect(x0, y0, width, height, Math.min(width, height) * 0.22); ctx.fill(); }
      else ctx.fillRect(x0, y0, width, height);
    }
  }
  async function load() {
    if (!codeId) { loading.hidden = true; error.hidden = false; error.textContent = 'Identifiant du QR code manquant.'; return; }
    try {
      const [response, healthResponse] = await Promise.all([
        fetch(`${isManager ? '/api/manager' : '/api/admin'}/codes/${encodeURIComponent(codeId)}`, { credentials: 'same-origin' }),
        fetch('/api/health'),
      ]);
      const payload = await response.json();
      const health = await healthResponse.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || 'QR code introuvable.');
      const code = payload.data;
      const publicBaseUrl = health.publicBaseUrl || window.location.origin;
      await draw($('#printCanvas'), code, publicBaseUrl);
      $('#printName').textContent = code.name;
      $('#printBeneficiary').textContent = code.beneficiaryName;
      $('#printUrl').textContent = `${publicBaseUrl}/r/${code.publicCode}`;
      $('#printIdentifier').textContent = `ID ${code.publicCode} · Généré avec Oymike QR`;
      document.title = `${code.name} — Oymike QR`;
      card.hidden = false; actions.hidden = false; loading.hidden = true;
    } catch (failure) { loading.hidden = true; error.hidden = false; error.textContent = failure.message; }
  }
  $('#printButton').addEventListener('click', () => window.print());
  load();
})();
